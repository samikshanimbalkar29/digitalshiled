<?php include "db.php"; ?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Emergency Helplines - Digital Shield</title>
  <link rel="stylesheet" href="style.css">
  <style>
    ul {
      list-style: none;
      padding: 0;
      max-width: 600px;
      margin: 30px auto;
    }

    ul li {
      background: #fff;
      color: #0072ff;
      padding: 20px;
      margin: 15px 0;
      font-size: 1.3em;
      border-radius: 12px;
      box-shadow: 0 5px 15px rgba(0,0,0,0.2);
      display: flex;
      align-items: center;
      gap: 15px;
    }

    ul li::before {
      content: "📞";
      font-size: 1.5em;
    }

    h1 {
      text-align: center;
      margin-top: 30px;
      font-size: 2.5em;
    }

    .container {
      padding: 50px 20px;
    }

    a.back {
      display: inline-block;
      margin-top: 30px;
      text-decoration: none;
      color: #fff;
      font-weight: bold;
      text-align: center;
    }

    a.back:hover {
      text-decoration: underline;
    }
  </style>
</head>
<body>
  <div class="container">
    <h1>🚨 Emergency Helplines</h1>
    <ul>
      <li>Cybercrime Helpline: 1930</li>
      <li>Police Helpline: 100</li>
      <li>Bank Fraud Helpline: Contact your bank’s official number</li>
    </ul>
    <a href="index.php" class="back">← Back to Homepage</a>
  </div>
</body>
</html>
