<?php include "db.php"; ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Digital Shield - Home</title>
    <link rel="stylesheet" href="style.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&display=swap" rel="stylesheet">
    <style>
        body {
            font-family: 'Poppins', sans-serif;
            background: linear-gradient(to right, #00c6ff, #0072ff);
            color: #333;
            text-align: center;
            padding: 30px;
        }

        .container {
            max-width: 700px;
            margin: auto;
            background: #fff;
            padding: 40px;
            border-radius: 20px;
            box-shadow: 0 0 20px rgba(0,0,0,0.1);
        }

        h1 {
            font-size: 2.5em;
            color: #3498db; /* updated main color */
            margin-bottom: 10px;
        }

        h3 {
            color: #666;
            margin-bottom: 30px;
        }

        .button {
            display: block;
            background-color: #3498db; /* updated main color */
            color: white;
            text-decoration: none;
            font-size: 1.2em;
            padding: 15px;
            margin: 15px auto;
            border-radius: 12px;
            width: 80%;
            transition: 0.3s;
        }

        .button:hover {
            background-color: #2980b9; /* updated hover color */
            transform: scale(1.05);
        }

        .section {
            margin-top: 30px;
        }

        .img-box {
            display: flex;
            justify-content: center;
            flex-wrap: wrap;
            gap: 20px;
        }

        .img-box img {
            width: 120px;
            height: 120px;
            border-radius: 50%;
            object-fit: cover;
            border: 3px solid #3498db; /* updated border color */
        }

        footer {
            margin-top: 40px;
            font-size: 0.9em;
            color: #777;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>🛡️ Digital Shield</h1>
        <h3>Helping Seniors Stay Safe Online</h3>

        <div class="img-box">
            <img src="https://cdn-icons-png.flaticon.com/512/942/942748.png" alt="Awareness">
            <img src="https://cdn-icons-png.flaticon.com/512/3135/3135715.png" alt="Verification">
            <img src="https://cdn-icons-png.flaticon.com/512/3050/3050525.png" alt="Reporting">
            <img src="https://cdn-icons-png.flaticon.com/512/3050/3050402.png" alt="Helpline">
        </div>

        <div class="section">
            <a href="tutorials.php" class="button">📘 1. Awareness Tutorials</a>
            <a href="verify.php" class="button">🔍 2. Fraud Verification Tool</a>
            <a href="report.php" class="button">📝 3. Report Scams</a>
                <a href="viewscams.php" class="button">📝 4. View Scams</a>
            <a href="helpline.php" class="button">☎️ 5. Emergency Helpline Info</a>
        </div>

        <footer>
            <p>Stay alert. Stay safe. Your online safety matters!</p>
        </footer>
    </div>
</body>
</html>
