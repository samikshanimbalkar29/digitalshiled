<?php include "db.php"; ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Report Scams</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="container">
        <h1>Report Scams</h1>
        <form method="POST">
            <input type="text" name="name" placeholder="Your Name" required>
            <input type="text" name="contact" placeholder="Phone or Email" required>
            <textarea name="description" placeholder="Describe the scam" required></textarea>
            <button type="submit" name="submit">Submit Report</button>
        </form>

        <?php
        if(isset($_POST['submit'])){
            $name = $_POST['name'];
            $contact = $_POST['contact'];
            $description = $_POST['description'];

            $sql = "INSERT INTO reports (name, contact, description) VALUES ('$name','$contact','$description')";
            if($conn->query($sql) === TRUE){
                echo "<p class='result safe'>Report submitted successfully!</p>";
            } else {
                echo "<p class='result fraud'>Error: ".$conn->error."</p>";
            }
        }
        ?>
        <a href="index.php" class="back">← Back to Homepage</a>
    </div>
</body>
</html>
