<?php
include "db.php";

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $name = $_POST['name'];
    $contact = $_POST['contact'];
    $desc = $_POST['description'];

    $sql = "INSERT INTO reports (name, contact, description) VALUES (?, ?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("sss", $name, $contact, $desc);

    if ($stmt->execute()) {
        echo "<p style='color:green;'>✅ Thank you! Your report has been submitted.</p>";
        echo "<a href='index.html'>Back to Home</a>";
    } else {
        echo "<p style='color:red;'>❌ Error submitting report.</p>";
    }
}
?>
