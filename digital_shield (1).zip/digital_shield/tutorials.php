<?php include "db.php"; ?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Awareness Tutorials - Digital Shield</title>
  <link rel="stylesheet" href="style.css">
  <style>
    .card {
      background: #fff;
      color: #000;
      padding: 30px;
      border-radius: 12px;
      box-shadow: 0 5px 20px rgba(0,0,0,0.2);
      max-width: 800px;
      margin: 30px auto;
      text-align: center;
    }

    h1, h2 {
      color: #fff;
    }

    p {
      font-size: 1.2em;
      line-height: 1.6;
    }

    img, video, audio {
      display: block;
      margin: 20px auto;
      max-width: 100%;
      border-radius: 12px;
    }

    .back {
      display: inline-block;
      margin-top: 30px;
      text-decoration: none;
      color: #fff;
      font-weight: bold;
    }

    .back:hover {
      text-decoration: underline;
    }
  </style>
</head>
<body>
  <div class="container">
    <h1>Awareness Tutorials</h1>

    <!-- Text Section -->
    <div class="card">
      <h2>Text Guide</h2>
      <p>1. Never share OTP or passwords with anyone.<br>
         2. Verify sender details in emails before clicking links.<br>
         3. Avoid unknown calls asking for money.<br>
         4. Always report suspicious messages to authorities.</p>
    </div>

    <!-- Image Section -->
    <div class="card">
      <h2>Images / Infographics</h2>
      <p>Example: How to identify a phishing email.</p>
      <img src="Images\emailphising.jpg" alt="Example Scam Email">
    </div>

    <!-- Video Section -->
<div class="card">
  <h2>Video Guide</h2>
  <p>Watch step-by-step how to check a suspicious link:</p>

  <iframe width="600" height="350" 
    src="https://www.youtube.com/embed/uAJlENFIN9o" 
    title="YouTube video"
    frameborder="0" 
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" 
    allowfullscreen>
  </iframe>
</div>

    <!-- Audio Section -->
    <div class="card">
      <h2>Voice / Audio Guide</h2>
      <p>Listen to simple steps to stay safe online:</p>
      <audio controls>
        <source src="audio/voice_guide.mp3" type="audio/mpeg">
        Your browser does not support the audio element.
      </audio>
    </div>

    <a href="index.php" class="back">← Back to Homepage</a>
  </div>
</body>
</html>
