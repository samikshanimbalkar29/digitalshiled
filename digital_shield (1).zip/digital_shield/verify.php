<?php include "db.php"; ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Fraud Verification Tool</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="container">
        <h1>Fraud Verification Tool</h1>
        <form method="POST">
            <input type="text" name="input" placeholder="Enter Phone, Email or URL" required>
            <button type="submit">Check</button>
        </form>

        <?php
        if ($_SERVER['REQUEST_METHOD'] == 'POST') {
            $input = $_POST['input'];
            $sql = "SELECT * FROM scams WHERE value = ?";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("s", $input);
            $stmt->execute();
            $result = $stmt->get_result();

            if ($result->num_rows > 0) {
                $row = $result->fetch_assoc();
                echo "<p class='result fraud'>⚠ Alert! This is a reported fraud: {$row['details']}</p>";
            } else {
                echo "<p class='result safe'>✅ Safe! No record found.</p>";
            }
        }
        ?>
        <a href="index.php" class="back">← Back to Homepage</a>
    </div>
</body>
</html>
