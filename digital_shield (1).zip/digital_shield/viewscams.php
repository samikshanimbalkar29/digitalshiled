<?php include "db.php"; ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>View Reported Scams - Fraud Detection System</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            padding: 20px;
        }

        .container {
            max-width: 1200px;
            margin: 0 auto;
            background: white;
            border-radius: 15px;
            box-shadow: 0 20px 40px rgba(0,0,0,0.1);
            overflow: hidden;
        }

        .header {
            background: linear-gradient(135deg, #2c3e50, #34495e);
            color: white;
            padding: 30px;
            text-align: center;
        }

        .header h1 {
            font-size: 2.5em;
            margin-bottom: 10px;
        }

        .header p {
            font-size: 1.1em;
            opacity: 0.9;
        }

        .controls {
            padding: 20px;
            background: #f8f9fa;
            border-bottom: 1px solid #e9ecef;
            display: flex;
            justify-content: space-between;
            align-items: center;
            flex-wrap: wrap;
            gap: 15px;
        }

        .search-box {
            flex: 1;
            min-width: 300px;
            position: relative;
        }

        .search-box input {
            width: 100%;
            padding: 12px 20px;
            border: 2px solid #e9ecef;
            border-radius: 25px;
            font-size: 16px;
            transition: all 0.3s ease;
        }

        .search-box input:focus {
            outline: none;
            border-color: #667eea;
            box-shadow: 0 0 0 3px rgba(102, 126, 234, 0.1);
        }

        .filters {
            display: flex;
            gap: 10px;
            flex-wrap: wrap;
        }

        .filter-btn {
            padding: 10px 20px;
            border: 2px solid #667eea;
            background: white;
            color: #667eea;
            border-radius: 25px;
            cursor: pointer;
            transition: all 0.3s ease;
            font-weight: 500;
        }

        .filter-btn:hover, .filter-btn.active {
            background: #667eea;
            color: white;
        }

        .stats {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 20px;
            padding: 20px;
            background: #f8f9fa;
        }

        .stat-card {
            background: white;
            padding: 20px;
            border-radius: 10px;
            text-align: center;
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
        }

        .stat-number {
            font-size: 2em;
            font-weight: bold;
            color: #667eea;
            margin-bottom: 5px;
        }

        .stat-label {
            color: #6c757d;
            font-size: 0.9em;
        }

        .scams-list {
            padding: 20px;
        }

        .scam-card {
            background: white;
            border: 1px solid #e9ecef;
            border-radius: 10px;
            padding: 25px;
            margin-bottom: 20px;
            transition: all 0.3s ease;
            box-shadow: 0 5px 15px rgba(0,0,0,0.05);
        }

        .scam-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 10px 25px rgba(0,0,0,0.1);
        }

        .scam-header {
            display: flex;
            justify-content: space-between;
            align-items: flex-start;
            margin-bottom: 15px;
            flex-wrap: wrap;
            gap: 10px;
        }

        .scam-contact {
            font-size: 1.2em;
            font-weight: bold;
            color: #2c3e50;
            word-break: break-all;
        }

        .scam-type {
            background: #e74c3c;
            color: white;
            padding: 5px 12px;
            border-radius: 20px;
            font-size: 0.8em;
            font-weight: bold;
        }

        .scam-description {
            color: #555;
            line-height: 1.6;
            margin-bottom: 15px;
        }

        .scam-meta {
            display: flex;
            justify-content: space-between;
            align-items: center;
            color: #888;
            font-size: 0.9em;
            border-top: 1px solid #e9ecef;
            padding-top: 15px;
        }

        .scam-reporter {
            font-weight: 500;
            color: #667eea;
        }

        .scam-date {
            color: #6c757d;
        }

        .no-results {
            text-align: center;
            padding: 40px;
            color: #6c757d;
            font-size: 1.1em;
        }

        .pagination {
            display: flex;
            justify-content: center;
            align-items: center;
            padding: 20px;
            gap: 10px;
        }

        .page-btn {
            padding: 10px 15px;
            border: 1px solid #dee2e6;
            background: white;
            color: #667eea;
            border-radius: 5px;
            cursor: pointer;
            transition: all 0.3s ease;
        }

        .page-btn:hover, .page-btn.active {
            background: #667eea;
            color: white;
            border-color: #667eea;
        }

        .back-btn {
            display: inline-block;
            padding: 12px 25px;
            background: #667eea;
            color: white;
            text-decoration: none;
            border-radius: 25px;
            transition: all 0.3s ease;
            margin: 20px;
            font-weight: 500;
        }

        .back-btn:hover {
            background: #5a6fd8;
            transform: translateY(-2px);
        }

        @media (max-width: 768px) {
            .controls {
                flex-direction: column;
                align-items: stretch;
            }
            
            .search-box {
                min-width: 100%;
            }
            
            .scam-header {
                flex-direction: column;
                align-items: flex-start;
            }
            
            .header h1 {
                font-size: 2em;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>📋 Reported Scams </h1>
            <p>Community-reported fraudulent activities and scam attempts</p>
        </div>

        <?php
        // Get total count
        $total_sql = "SELECT COUNT(*) as total FROM reports";
        $total_result = $conn->query($total_sql);
        $total_row = $total_result->fetch_assoc();
        $total_reports = $total_row['total'];

        // Get recent count (last 7 days)
        $recent_sql = "SELECT COUNT(*) as recent FROM reports WHERE created_at >= DATE_SUB(NOW(), INTERVAL 7 DAY)";
        $recent_result = $conn->query($recent_sql);
        $recent_row = $recent_result->fetch_assoc();
        $recent_reports = $recent_row['recent'];

        // Get unique reporters count
        $reporters_sql = "SELECT COUNT(DISTINCT name) as reporters FROM reports";
        $reporters_result = $conn->query($reporters_sql);
        $reporters_row = $reporters_result->fetch_assoc();
        $unique_reporters = $reporters_row['reporters'];
        ?>

        <div class="stats">
            <div class="stat-card">
                <div class="stat-number"><?php echo $total_reports; ?></div>
                <div class="stat-label">Total Reports</div>
            </div>
            <div class="stat-card">
                <div class="stat-number"><?php echo $recent_reports; ?></div>
                <div class="stat-label">Last 7 Days</div>
            </div>
            <div class="stat-card">
                <div class="stat-number"><?php echo $unique_reporters; ?></div>
                <div class="stat-label">Unique Reporters</div>
            </div>
        </div>

        <div class="controls">
            <div class="search-box">
                <input type="text" id="searchInput" placeholder="🔍 Search scams by contact info, description, or reporter...">
            </div>
            <div class="filters">
                <button class="filter-btn active" data-filter="all">All Reports</button>
                <button class="filter-btn" data-filter="recent">Recent First</button>
                <button class="filter-btn" data-filter="oldest">Oldest First</button>
            </div>
        </div>

        <div class="scams-list" id="scamsList">
            <?php
            // Pagination setup
            $results_per_page = 10;
            $page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
            $start_from = ($page - 1) * $results_per_page;

            // Get reports with pagination
            $sql = "SELECT * FROM reports ORDER BY created_at DESC LIMIT $start_from, $results_per_page";
            $result = $conn->query($sql);

            if ($result->num_rows > 0) {
                while($row = $result->fetch_assoc()) {
                    $contact = htmlspecialchars($row['contact']);
                    $description = htmlspecialchars($row['description']);
                    $reporter = htmlspecialchars($row['name']);
                    $date = date('M j, Y \a\t g:i A', strtotime($row['created_at']));
                    
                    // Determine scam type based on contact info
                    $scam_type = "Unknown";
                    if (filter_var($contact, FILTER_VALIDATE_EMAIL)) {
                        $scam_type = "Email Scam";
                    } elseif (preg_match('/^\+?[\d\s\-\(\)]+$/', $contact)) {
                        $scam_type = "Phone Scam";
                    } elseif (filter_var($contact, FILTER_VALIDATE_URL)) {
                        $scam_type = "Website Scam";
                    }
                    ?>
                    
                    <div class="scam-card" data-contact="<?php echo strtolower($contact); ?>" data-description="<?php echo strtolower($description); ?>" data-reporter="<?php echo strtolower($reporter); ?>">
                        <div class="scam-header">
                            <div class="scam-contact"><?php echo $contact; ?></div>
                            <!-- <div class="scam-type"><?php echo $scam_type; ?></div> -->
                        </div>
                        <div class="scam-description">
                            <?php echo nl2br($description); ?>
                        </div>
                        <div class="scam-meta">
                            <div class="scam-reporter">Reported by: <?php echo $reporter; ?></div>
                            <div class="scam-date"><?php echo $date; ?></div>
                        </div>
                    </div>
                    <?php
                }
            } else {
                echo '<div class="no-results">No scam reports found. Be the first to report a scam!</div>';
            }

            // Pagination links
            $sql = "SELECT COUNT(*) AS total FROM reports";
            $result = $conn->query($sql);
            $row = $result->fetch_assoc();
            $total_pages = ceil($row["total"] / $results_per_page);

            if ($total_pages > 1) {
                echo '<div class="pagination">';
                for ($i = 1; $i <= $total_pages; $i++) {
                    $active = $i == $page ? 'active' : '';
                    echo "<a href='viewscams.php?page=$i' class='page-btn $active'>$i</a>";
                }
                echo '</div>';
            }
            ?>
        </div>

        <div style="text-align: center; padding: 20px;">
            <a href="index.php" class="back-btn">← Back to Homepage</a>
            <a href="reportscams.php" class="back-btn" style="background: #28a745;">➕ Report New Scam</a>
        </div>
    </div>

    <script>
        // Search functionality
        document.getElementById('searchInput').addEventListener('input', function() {
            const searchTerm = this.value.toLowerCase();
            const scamCards = document.querySelectorAll('.scam-card');
            
            scamCards.forEach(card => {
                const contact = card.getAttribute('data-contact');
                const description = card.getAttribute('data-description');
                const reporter = card.getAttribute('data-reporter');
                
                if (contact.includes(searchTerm) || description.includes(searchTerm) || reporter.includes(searchTerm)) {
                    card.style.display = 'block';
                } else {
                    card.style.display = 'none';
                }
            });
        });

        // Filter functionality
        document.querySelectorAll('.filter-btn').forEach(btn => {
            btn.addEventListener('click', function() {
                // Remove active class from all buttons
                document.querySelectorAll('.filter-btn').forEach(b => b.classList.remove('active'));
                // Add active class to clicked button
                this.classList.add('active');
                
                const filter = this.getAttribute('data-filter');
                // In a real application, this would reload the page with different sorting
                // For now, we'll just show an alert
                switch(filter) {
                    case 'recent':
                        window.location.href = 'viewscams.php?sort=recent';
                        break;
                    case 'oldest':
                        window.location.href = 'viewscams.php?sort=oldest';
                        break;
                    default:
                        window.location.href = 'viewscams.php';
                }
            });
        });

        // Add some interactive effects
        document.addEventListener('DOMContentLoaded', function() {
            const cards = document.querySelectorAll('.scam-card');
            cards.forEach((card, index) => {
                card.style.animationDelay = (index * 0.1) + 's';
                card.style.animation = 'fadeInUp 0.6s ease-out';
            });
        });

        // Add CSS animation
        const style = document.createElement('style');
        style.textContent = `
            @keyframes fadeInUp {
                from {
                    opacity: 0;
                    transform: translateY(30px);
                }
                to {
                    opacity: 1;
                    transform: translateY(0);
                }
            }
            .scam-card {
                animation-fill-mode: both;
            }
        `;
        document.head.appendChild(style);
    </script>
</body>
</html>
<?php $conn->close(); ?>